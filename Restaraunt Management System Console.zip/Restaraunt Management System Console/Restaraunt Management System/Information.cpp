#include "Information.h"
//constructor 
Information::Information()
{
	Name="";
	Address="";
	City="";
	Area="";
	phoneNumber=0;
	
}
//destructor
Information::~Information()
{
	
}

void Information::Welcome()
{
	std::cout<<std::endl<<"Welcome"<<std::endl;
	
	
	
}
void Information::PizzaMenu()
{
	std::cout<<std::endl<<"Pizza Menu"<<std::endl;
}
void Information::RollMenu()
{
	std::cout<<std::endl<<"Roll Menu"<<std::endl;
}
void Information::BurgerMenu()
{
	std::cout<<std::endl<<"Burger Menu"<<std::endl;
}
void Information::SandwhichMenu()
{
	std::cout<<std::endl<<"Sandwhich Menu"<<std::endl;
}
void Information::FriesMenu()
{
	std::cout<<std::endl<<"Fries Menu"<<std::endl;
}
void Information::ShowMenu()
{
	std::cout<<std::endl<<"Show Menu"<<std::endl;
}
void Information::BillAmount()
{
	std::cout<<std::endl<<"Bill Amount"<<std::endl;
}