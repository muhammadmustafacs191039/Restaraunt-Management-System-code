#ifndef INFORMATION_H
#define INFORMATION_H
#include<string.h>
#include<iostream>
class Information{
	protected:
	//name string to initialize customer name
	std::string Name;
	//Address string to initalize customer address
	std::string Address;
	//City string to input users city
	std::string City;
	//user area input
	std::string Area;
	//double variable to input user phone number
	double phoneNumber;
	public:
	//class constructor
	Information();
	//class destructor
	virtual ~Information();
	//functions defined used in derived classes
	virtual void Welcome();
	virtual void ShowMenu();
	virtual void BurgerMenu();
	virtual void PizzaMenu();
	virtual void RollMenu();
	virtual void SandwhichMenu();
	virtual void FriesMenu();
	virtual void BillAmount();
	
};
#endif