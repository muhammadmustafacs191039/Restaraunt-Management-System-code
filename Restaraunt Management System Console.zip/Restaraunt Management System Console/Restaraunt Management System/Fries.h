#ifndef FRIES_H
#define FRIES_H
#include "Menu.h"
#include<iostream>
//class Fries is inheriting properties of class Menu by virtual public inheritance due to ambiguity
class Fries : virtual public Menu{
	protected:
	//variables to initialize fries prices
	int PlainFries;
	int CheeseFries;
	int MayoFries;
	int choiceFries;
	public:
	//constructor
	Fries();
	//destructor
	~Fries();
	//function to display fries menu
	void FriesMenu();
	
	
};
#endif