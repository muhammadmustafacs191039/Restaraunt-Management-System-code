//Included All header files
#include "Menu.h"
#include "Pizza.h"
#include "Burger.h"
#include "Roll.h"
#include "Sandwhich.h"
#include "Fries.h"
#include "Billing.h"
#include<iostream>
#include<string>

int main()
{
	
	//int variable to check choice menu of user
	int Choice=0;
		
	//declaring base class pointer variable to point class Menu
	Information* a = new Menu();
	a->Welcome();
	
	std::cout<<std::endl<<std::endl<<std::endl;
	
	//declaring base class pointer variable to point class Menu
	Information* i = new Menu();
	i->ShowMenu();
	
	std::cout<<std::endl<<std::endl<<std::endl<<std::endl<<"\t\t\t\t\t\tEnter Choice : ";
	std::cin>>Choice;
	//condition to check the user choice display menu and if choice out of ran display error
	if(Choice>=1 && Choice<=5)
	{
		//if user enter 1 this code will execute
		if(Choice==1)
		{
			//declaring base class pointer variable to point class Burger
			Information* burger = new Burger();
			burger->BurgerMenu();
			//declaring base class pointer variable to point class Billing
			Information* bill = new Billing();
			bill->BillAmount();
			//deleting pointer variables to avoid memory leak
			delete burger;
			delete bill;
		}
		//if user enter 2 this code will execute
		else if(Choice==2)
		{
			//declaring base class pointer variable to point class Roll
			Information* roll = new Roll();
			roll->RollMenu();
			//declaring base class pointer variable to point class Billing
			Information* bill = new Billing();
			bill->BillAmount();
			//deleting pointer variables to avoid memory leak
			delete roll;
			delete bill;
		}
		//if user enter 3 this code will execute
		else if(Choice==3)
		{
			//declaring base class pointer variable to point class Pizza
			Information* pizza = new Pizza();
			pizza->PizzaMenu();	
			//declaring base class pointer variable to point class Billing
			Information* bill = new Billing();
			bill->BillAmount();
			//deleting pointer variables to avoid memory leak
			delete pizza;
			delete bill;
		}	
		//if user enter 4 this code will execute
		else if(Choice==4)
		{
			//declaring base class pointer variable to point class Sandwhich
			Information* sandwhich = new Sandwhich();
			sandwhich->SandwhichMenu();		
			//declaring base class pointer variable to point class Billing
			Information* bill = new Billing();
			bill->BillAmount();
			//deleting pointer variables to avoid memory leak
			delete sandwhich;
			delete bill;
		}
		//if user enter 5 this code will execute
		else if(Choice==5)
		{
			//declaring base class pointer variable to point class Fries
			Information* fries = new Fries();
			fries->FriesMenu();	
			//declaring base class pointer variable to point class Billing
			Information* bill = new Billing();
			bill->BillAmount();
			//deleting pointer variables to avoid memory leak
			delete fries;
			delete bill;
		}
		
	}
	//if user enters invalid choice then this else block will be executed
	else
	{
		std::cout<<"Invalid Choice "<<std::endl;
	}
	
	//if user enters wrong login passcode this else block will execute displaying error
	
	return 0;
}
