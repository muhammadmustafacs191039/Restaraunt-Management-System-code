#include "Burger.h"
//constructor
Burger::Burger()
{
	//burger prices set 
	MightyZinger=600;
	ZingerStacker=400;
	CrunchBurger=200;
	choiceBurger=0;
}
//destructor
Burger::~Burger()
{
	
}
//function to display different types of burgers
void Burger::BurgerMenu()
{
	//function displaying different types of burgers and prices
	std::cout<<std::endl<<"\t\t\t\t\t\tOur Burger's"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t1. Chicken Mighty Zinger Rs.600 "<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t2. Chicken Zinger Stacker Rs.400 "<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t3. Chicken Crunch Burger Rs.200 "<<std::endl;
	
}