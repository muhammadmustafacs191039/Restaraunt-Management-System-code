#ifndef MENU_H
#define MENU_H
#include "Information.h"
#include<iostream>
#include <fstream>
class Menu : public Information{
	public:
	//class constructor
	Menu();
	//class destructor
	~Menu();
	//function to display food menu
	void ShowMenu();
	//function to take customer info and display
	void Welcome();
	
	
	
};
#endif