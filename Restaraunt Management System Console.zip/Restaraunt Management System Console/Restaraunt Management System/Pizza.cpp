#include "Pizza.h"
#include<iostream>
//constructor
Pizza::Pizza()
{
	//disfferent sizes pizza price set
	smallPizza=300;
	regularPizza=500;
	largePizza=1000;
	choicePizza=0;
}
//destructor
Pizza::~Pizza()
{
	
}
//function to display different types of Pizza Menu
void Pizza::PizzaMenu(){
	std::cout<<std::endl<<"\t\t\t\t\t\tOur Pizza Flavour's"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t1.Chicken Fajita"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t2.Chicken Barbeque"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t3.Chicken Creamy"<<std::endl;
}