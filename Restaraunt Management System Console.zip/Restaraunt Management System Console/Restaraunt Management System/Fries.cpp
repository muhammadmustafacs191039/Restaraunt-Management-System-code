#include "Fries.h"
//constructor
Fries::Fries()
{
	PlainFries=100;
	CheeseFries=160;
	MayoFries=190;
	choiceFries=0;
}
//destructor
Fries::~Fries()
{
	
}
//function to display fries menu
void Fries::FriesMenu()
{
	std::cout<<std::endl<<"\t\t\t\t\t\tOur Special Fries"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t1.Plain Fries Rs.100"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t2.Cheese Fries Rs.160"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t3.Mayo Fries Rs.190"<<std::endl;
}