#include "Sandwhich.h"
//constructor
Sandwhich::Sandwhich()
{
	GrilledSandwhich=220;
	ClubSandwhich=320;
	BeefSandwhich=370;
	choiceSandwhich=0;
}
//destructor
Sandwhich::~Sandwhich()
{
	
}
//function to display different types of sandwhiches
void Sandwhich::SandwhichMenu()
{
	std::cout<<std::endl<<"\t\t\t\t\t\tOur Special Sandwhiches"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t1.Chicken Grilled Sandwhich Rs.220"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t2.Chicken Club Sandwhich Rs.320"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t3.Beef Sandwhich Rs.370"<<std::endl;
}