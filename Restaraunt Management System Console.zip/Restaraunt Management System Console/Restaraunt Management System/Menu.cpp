#include "Menu.h"
//constructor
Menu::Menu()
{
	
}
//destructor
Menu::~Menu()
{
	
}
//function to display food menu
void Menu::ShowMenu()
{
	
	std::cout<<"********************************************************         M E  N U          ***************************************************************************"<<std::endl;
	std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\t1.Burger's"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t2.Roll's"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t3.Pizza's"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t4.Sandwiches"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t5.Fries"<<std::endl;
	std::cout<<std::endl<<std::endl<<std::endl;
	std::cout<<"**************************************************************************************************************************************************************"<<std::endl;
	
	//creating writing type file object to write data into file
	std::ofstream showmenu;
	//opening file in append mode for writing 
	showmenu.open("showmenufile.txt",std::ios::app);
	if(showmenu.is_open())
	{
		showmenu<<std::endl<<std::endl<<"\t\t\t\t\t\t1.Burger's"<<std::endl;
		showmenu<<std::endl<<"\t\t\t\t\t\t2.Roll's"<<std::endl;
		showmenu<<std::endl<<"\t\t\t\t\t\t3.Pizza's"<<std::endl;
		showmenu<<std::endl<<"\t\t\t\t\t\t4.Sandwiches"<<std::endl;
		showmenu<<std::endl<<"\t\t\t\t\t\t5.Fries"<<std::endl;
		
	}
	else
	{
		std::cout<<std::endl<<"Not able to open file "<<std::endl;
	}
}

//function to take users information
void Menu::Welcome()
{
	std::cout<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl<<"\t\t\t\t**********************ENTER YOUR INFORMATION*************************";
	std::cout<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl;
	std::cout<<"\t\t\t\t\t\tEnter Your Name : ";
	
	std::cin>>Name;
	std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tEnter your Address : ";
	std::cin>>Address;
	
	std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tEnter your City : ";
	std::cin>>City;
	
	std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tEnter your Area : ";
	std::cin>>Area;
	
	std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tEnter your Phone Number : ";
	std::cin>>phoneNumber;

	std::cout<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl;
	std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl;
	
	//creating writing type file object to write data into file

	std::ofstream myfile;
	//opening file in append mode for writing
	myfile.open("Info.txt",std::ios::app);
	if (myfile.is_open())
	{
		myfile<<Name<<std::endl;
		myfile<<Address<<std::endl;
		myfile<<City<<std::endl;
		myfile<<Area<<std::endl;
		myfile<<phoneNumber<<std::endl;
		myfile.close();		
	}
	else
	{
		//displaying message in case of failing in opening in file
		std::cout << "Unable to open file";
	}

	std::cout<<std::endl<<"\t\t\t\t\t\t Hello ' "<<Name<<" ' Welcome to Our Restaraunt Service "<<std::endl;
	std::cout<<"\t\t\t\t\t\t What would you Like to Order ?? "<<std::endl;
}