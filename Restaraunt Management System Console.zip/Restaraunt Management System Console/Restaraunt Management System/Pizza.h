#ifndef PIZZA_H
#define PIZZA_H
#include "Menu.h"
//class Pizza is inheriting properties of class Menu by virtual public inheritance due to ambiguity
class Pizza : virtual public Menu {
	protected:
	//variable to mentio different sizes of pizza and their prices
	int smallPizza;
	int regularPizza;
	int largePizza;
	int choicePizza;
	public:
	//class constructor
	Pizza();
	//class destructor
	~Pizza();
	//function to display different types of pizza
	void PizzaMenu();
	
	
	
};
#endif