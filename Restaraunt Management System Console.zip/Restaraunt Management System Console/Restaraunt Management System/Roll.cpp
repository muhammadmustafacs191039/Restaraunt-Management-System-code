#include "Roll.h"
#include<iostream>
//constructor
Roll::Roll()
{
	MayoRoll=180;
	ChatniRoll=110;
	CreamyRoll=150;
}
//destructor
Roll::~Roll()
{

}
//function to display different types of roll
void Roll::RollMenu(){
	std::cout<<std::endl<<"\t\t\t\t\t\tOur Special Roll's"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t1.Chicken Mayo Roll Rs.180"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t1.Chicken Creamy Roll Rs.150"<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\t1.Chicken Chatni Roll Rs.110"<<std::endl;
	
}