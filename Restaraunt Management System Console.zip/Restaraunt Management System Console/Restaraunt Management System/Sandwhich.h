#ifndef SANDWHICH_H
#define SANDWHICH_H
#include "Menu.h"
#include<iostream>
//class Sandwhich is inheriting properties of class Menu by virtual public inheritance due to ambiguity
class Sandwhich : virtual public Menu{
	protected:
	//variables to initialize sandwhich prices
	int GrilledSandwhich;
	int ClubSandwhich;
	int BeefSandwhich;
	int choiceSandwhich;
	public:
	//constructor
	Sandwhich();
	//destructor
	~Sandwhich();
	//function to show sandwhich menu
	void SandwhichMenu();

	
};
#endif