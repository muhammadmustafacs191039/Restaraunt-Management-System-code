#include "Billing.h"
#include<iostream>
//constructor
Billing::Billing()
{
	quantity=0;
	totalbill=0;
}
//destructor
Billing::~Billing()
{
	
}
//function to calculate total bill of ordered food by user
void Billing::BillAmount()
{
	//variable to confirm user food choice
	int confirmChoice=0;
	std::cout<<std::endl<<std::endl<<std::endl<<"\t\t\t\t\t\t*****CONFIRM YOUR FOOD CHOICE*****"<<std::endl;
	std::cout<<std::endl<<std::endl<<std::endl<<"\t\t\t\t\t\tPLEASE PRESS 1 FOR BURGER "<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\tPLEASE PRESS 2 FOR ROLL "<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\tPLEASE PRESS 3 FOR PIZZA "<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\tPLEASE PRESS 4 FOR SANDWHICH "<<std::endl;
	std::cout<<std::endl<<"\t\t\t\t\t\tPLEASE PRESS 5 FOR FRIES "<<std::endl<<std::endl;
	//input confirmChoice
	std::cout<<"\t\t\t\t\t\tConfirm : ";
	std::cin>>confirmChoice;
	std::cout<<std::endl<<std::endl<<std::endl<<"\t\t\t\t\t\t**********************************"<<std::endl;
	//if user enters confirmChoice 1 for burger
	if(confirmChoice==1)
	{	std::cout<<std::endl<<std::endl<<std::endl;
		//input your burgerchoice
		std::cout<<"\t\t\t\t\t\tEnter your Burger Choice : ";
		std::cin>>choiceBurger;
		//condition set if burgerchoice not between 1-3 it will display error
		if(choiceBurger>=1 && choiceBurger<=3)
		{
			//if choiceBurger is 1 for MightyZinger this code will run
			if(choiceBurger==1)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*MightyZinger;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYou have ordered Mighty Zinger Burger "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Price is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file
				std::ofstream BurgerFile;
				//opening file in append mode for writing purpose
				BurgerFile.open("BurgerBill.txt",std::ios::app);
				if(BurgerFile.is_open())
				{
					BurgerFile<<"\t\t\t\t\t\tYou have ordered Mighty Zinger Burger "<<std::endl;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tTotal Price is = "<<totalbill;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";	
					BurgerFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
				
			}
			//if user enter choiceburger 2 ZingerStacker this code will run
			else if(choiceBurger==2)
			{
				
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*ZingerStacker;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Zinger Stacker Burger "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file
				std::ofstream BurgerFile;
				//opening file in append mode for writing
				BurgerFile.open("BurgerBill.txt",std::ios::app);
				if(BurgerFile.is_open())
				{
					BurgerFile<<"\t\t\t\t\t\tYou have ordered Zinger Stacker Burger "<<std::endl;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					BurgerFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
			}
			//if user enter choiceBurger 3 CrunchBurger this code will run
			else if(choiceBurger==3)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*CrunchBurger;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Crunch Burger "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream BurgerFile;
				//opening file in append mode for writing
				BurgerFile.open("BurgerBill.txt",std::ios::app);
				if(BurgerFile.is_open())
				{
					BurgerFile<<"\t\t\t\t\t\tYou have ordered Crunch Burger "<<std::endl;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					BurgerFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					BurgerFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
			}
		}
	}
	//if user enters confirmchoice 2 for roll this code will run
	else if(confirmChoice==2)
	{
		std::cout<<std::endl<<std::endl<<std::endl;
		//input roll flavour choice
		std::cout<<"Enter your Roll Choice : ";
		std::cin>>choiceRoll;
		//condition set for roll choice 
		if(choiceRoll>=1 && choiceRoll<=3 )
		{
			//if user enters choiceRoll 1 for MayoRoll
			if(choiceRoll==1)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*MayoRoll;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Mayo Roll "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream RollFile;
				//opening file in append mode for writing
				RollFile.open("RollBill.txt",std::ios::app);
				if(RollFile.is_open())
				{
					RollFile<<"\t\t\t\t\t\tYou have ordered Mayo Roll "<<std::endl;
					RollFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					RollFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					RollFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					RollFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
			}
			//if user enters choiceRoll 2 for CreamyRoll this code will run
			else if(choiceRoll==2)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*CreamyRoll;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Creamy Roll "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream RollFile;
				//opening file in append mode for writing
				RollFile.open("RollBill.txt",std::ios::app);
				if(RollFile.is_open())
				{
					RollFile<<"\t\t\t\t\t\tYou have ordered Creamy Roll "<<std::endl;
					RollFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					RollFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					RollFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					RollFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
			}
			//if user enters choiceRoll 3 for ChatniRoll this code will run
			else if(choiceRoll==3)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*ChatniRoll;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Chatni Roll "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream RollFile;
				//opening file in append mode for writing
				RollFile.open("RollBill.txt",std::ios::app);
				if(RollFile.is_open())
				{
					RollFile<<"\t\t\t\t\t\tYou have ordered Chicken Chatni Roll "<<std::endl;
					RollFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					RollFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					RollFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					RollFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
			}
		}
		//if user enter choiceRoll not between 1-3 this error message will display
		else
		{
			std::cout<<"\t\t\t\t\t\tInvalid Choice"<<std::endl;
		}
	}
	//if user enters confirmChoice 3 for pizza this code will run
	else if(confirmChoice==3)
	{
		std::cout<<std::endl<<std::endl<<std::endl;
		std::cout<<"\t\t\t\t\t\tEnter your Pizza Choice : ";
		//input choicePizza
		std::cin>>choicePizza;
		//condition set for choicePizza input to be b/w 1-3
		if(choicePizza>=1 && choicePizza<=3)
		{
			//variable for pizza size
			int size=0;
			//if user enters choicePizza 1 for Fajita pizza this code will run
			if(choicePizza==1)
			{
				
				std::cout<<std::endl<<"\t\t\t\t\t\t1.Small Pizza Rs.300 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\t2.Regular Pizza Rs.500 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\t3.Large Pizza Rs.1000 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter size choice : ";
				//size input from user
				std::cin>>size;
				//condition set for size input b/w 1-3
				if(size>=1 && size<=3)
				{
					//if user enters size 1 small
					if(size==1)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*smallPizza;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Fajita Pizza "<<std::endl;
						std::cout<<std::endl<<"Ordered size is : Small"<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Fajita Pizza "<<std::endl;
							PizzaFile<<std::endl<<"Ordered size is : Small"<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							//closing file
							PizzaFile.close();
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
						
					}
					//if user enters size 2 for regularPizza
					else if(size==2)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*regularPizza;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Fajita Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Regular"<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Fajita Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Regular"<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							//closing file
							PizzaFile.close();
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
							
					}
					//if user enters size 3 for large
					else if(size==3)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*largePizza;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Fajita Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Large"<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Fajita Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Large"<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							//closing file
							PizzaFile.close();
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
					}
				}
			}
			//if user enters choicePizza 2 barbeque pizza this code will run
			if(choicePizza==2)
			{
				
				std::cout<<std::endl<<"\t\t\t\t\t\t1.Small Pizza Rs.300 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\t2.Regular Pizza Rs.500 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\t3.Large Pizza Rs.1000 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter size choice : ";
				//input size from user
				std::cin>>size;
				//condtion set for size input b/w 1-3
				if(size>=1 && size<=3)
				{
					//if user enters size 1 for small
					if(size==1)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*smallPizza;
						std::cout<<std::endl<<std::endl<<std::endl;
  						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Barbeque Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Small"<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Barbeque Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Small"<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							//closing file
							PizzaFile.close();
						}
						//if file is not created
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
					}
					//if user enters size 2 for regularPizza
					else if(size==2)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*regularPizza;
						
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Barbeque Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Regular"<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Barbeque Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Regular"<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							//closing file
							PizzaFile.close();
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
						
					}
					//if user enters size 3 for largePizza
					else if(size==3)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*largePizza;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Barbeque Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Large"<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Barbeque Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Large"<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							//closing file
							PizzaFile.close();
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
					}
				}
			}
			//is user enters choicePizza 3 for Creamy pizza 
			if(choicePizza==3)
			{
				
				std::cout<<std::endl<<"\t\t\t\t\t\t1.Small Pizza Rs.300 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\t2.Regular Pizza Rs.500 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\t3.Large Pizza Rs.1000 "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter size choice : ";
				std::cin>>size;
				if(size>=1 && size<=3)
				{
					//if user enters size 1 for small
					if(size==1)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*smallPizza;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Creamy Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Small"<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Creamy Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Small"<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							PizzaFile.close();
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
					}
					//if suer enters size for regularPizza
					else if(size==2)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*regularPizza;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Creamy Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Regular "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Creamy Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Regular "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							PizzaFile.close();
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
						
					}
					//if user enters size 3 for largePizza
					else if(size==3)
					{
						std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
						std::cin>>quantity;
						totalbill=quantity*largePizza;
						std::cout<<std::endl<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
						std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Creamy Pizza "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tOrdered size is : Large "<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
						std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
						std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
						std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
						std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
						//opening file in append mode for writing
						std::ofstream PizzaFile;
						PizzaFile.open("pizzabill.txt",std::ios::app);
						if(PizzaFile.is_open())
						{
							PizzaFile<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
							PizzaFile<<"\t\t\t\t\t\tYou have ordered Chicken Creamy Pizza "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tOrdered size is : Large "<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
							PizzaFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
							PizzaFile<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
							
							PizzaFile.close();
						
						}
						else
						{
							std::cout<<std::endl<<"not able to open file "<<std::endl;
						}
					}
				}
			}
		}
		else 
		{
			std::cout<<std::endl<<"\t\t\t\t\t\tInvalid Choice"<<std::endl;
		}
	}
	
	//if user enters confirmChoice 4 for sandwhich
		if(confirmChoice==4)
	{	std::cout<<std::endl<<std::endl<<std::endl;
		std::cout<<"\t\t\t\t\t\tEnter your Sandwhich Choice : ";
		std::cin>>choiceSandwhich;
		//condition set for choiceSandwhich b/w 1-3
		if(choiceSandwhich>=1 && choiceSandwhich<=3)
		{
			//if choiceSandwhich is 1 for GrilledSandwhich
			if(choiceSandwhich==1)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*GrilledSandwhich;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYou have ordered Chicken Grilled Sandwhich "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream SandwhichFile;
				//opening file in append mode for writing
				SandwhichFile.open("SandwhichBill.txt",std::ios::app);
				if(SandwhichFile.is_open())
				{
					SandwhichFile<<"\t\t\t\t\t\tYou have ordered  Chicken Grilled Sandwhich"<<std::endl;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";	
					std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
					SandwhichFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
				
			}
			//if user enters choiceSandwhich 2 for clubSandwhich
			else if(choiceSandwhich==2)
			{
				
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*ClubSandwhich;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Chicken Club Sandwhich "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream SandwhichFile;
				//opening file in append mode for writing
				SandwhichFile.open("SandwhichBill.txt",std::ios::app);
				if(SandwhichFile.is_open())
				{
					SandwhichFile<<"\t\t\t\t\t\tYou have ordered Chicken ClubSandwhich "<<std::endl;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
					SandwhichFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
			}
			//if user enters choiceSandwhich 3 for beefsandwhich
			else if(choiceSandwhich==3)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*BeefSandwhich;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Beef Sandwhich "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream SandwhichFile;
				//opening file in append mode for writing
				SandwhichFile.open("SandwhichBill.txt",std::ios::app);
				if(SandwhichFile.is_open())
				{
					SandwhichFile<<"\t\t\t\t\t\tYou have ordered Beef Sandwhich "<<std::endl;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					SandwhichFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					SandwhichFile.close();
				}
				//opening file in append mode for writing
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
			}
		}
	}
	//if user enters confirmChoice 5 for fries
	if(confirmChoice==5)
	{	std::cout<<std::endl<<std::endl<<std::endl;
		std::cout<<"\t\t\t\t\t\tEnter your Fries Choice : ";
		//input choiceFries
		std::cin>>choiceFries;
		//condition set for choiceFries b/w 1-3
		if(choiceFries>=1 && choiceFries<=3)
		{
			//if choiceFries is 1 for PlainFries
			if(choiceFries==1)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*PlainFries;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYou have ordered Plain Fries "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream FriesFile;
				//opening file in append mode for writing
				FriesFile.open("FriesBill.txt",std::ios::app);
				if(FriesFile.is_open())
				{
					FriesFile<<"\t\t\t\t\t\tYou have ordered Plain Fries "<<std::endl;
					FriesFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					FriesFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					FriesFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";	
					FriesFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
				
			}
			//if choiceFries is 2 for CheeseFries
			else if(choiceFries==2)
			{
				
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*CheeseFries;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Cheese Fries "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream FriesFile;
				//opening file in append mode for writing
				FriesFile.open("FriesBill.txt",std::ios::app);
				if(FriesFile.is_open())
				{
					FriesFile<<"\t\t\t\t\t\tYou have ordered Zinger Stacker Burger "<<std::endl;
					FriesFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					FriesFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					FriesFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					FriesFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
				
			}
			//if user enters choiceFries 3 MayoFries
			else if(choiceFries==3)
			{
				std::cout<<std::endl<<"\t\t\t\t\t\tEnter quantity : ";
				std::cin>>quantity;
				totalbill=quantity*MayoFries;
				std::cout<<std::endl<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t\t\t**Bill Reciept** "<<std::endl;
				std::cout<<"\t\t\t\t\t\tYou have ordered Mayo Fries "<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
				std::cout<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
				std::cout<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
				std::cout<<std::endl<<std::endl<<"\t\t\t\t\t\tConctact us 03321145030"<<std::endl<<std::endl;
				std::cout<<"\t\t\t\t**********************************************************************"<<std::endl<<std::endl;
				//creating writing type file object to write data into file

				std::ofstream FriesFile;
				//opening file in append mode for writing
				FriesFile.open("FriesBill.txt",std::ios::app);
				if(FriesFile.is_open())
				{
					FriesFile<<"\t\t\t\t\t\tYou have ordered Crunch Burger "<<std::endl;
					FriesFile<<std::endl<<"\t\t\t\t\t\tYour Ordered Quantity is : "<<quantity<<std::endl;
					FriesFile<<std::endl<<"\t\t\t\t\t\tTotal Bill is = "<<totalbill;
					FriesFile<<std::endl<<"\t\t\t\t\t\tYour order will be delivered in 40 minutes";
					FriesFile.close();
				}
				//if file is not created
				else
				{
					std::cout<<std::endl<< "Unable to open file"<<std::endl;
				}
			}
		}
	}  
	
}