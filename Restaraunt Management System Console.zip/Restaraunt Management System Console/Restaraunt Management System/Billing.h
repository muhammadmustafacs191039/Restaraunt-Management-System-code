#ifndef BILLING_H
#define BILLING_H
#include "Burger.h"
#include "Pizza.h"
#include "Roll.h"
#include "Sandwhich.h"
#include "Fries.h"
#include <iostream>
#include <fstream>
class Billing : public Burger , public Roll , public Pizza, public Sandwhich, public Fries{
	private:
	//variable to initialize food quantity
	double quantity;
	//variable to initialize total bill
	double totalbill;
	public:
	//constructor
	Billing();
	//destructor
	~Billing();
	//function to display food bill amount
	void BillAmount();
	
	
	
	
};
#endif