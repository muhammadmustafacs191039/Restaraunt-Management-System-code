#ifndef BURGER_H
#define BURGER_H
#include "Menu.h"
#include<iostream>
//class burger is inheriting properties of class Menu by virtual public inheritance due to ambiguity
class Burger : virtual public Menu{
	protected:
	//variables to initialilze names and prices of burger's
	int MightyZinger;
	int ZingerStacker;
	int CrunchBurger;
	int choiceBurger;
	public:
	//class constructor
	Burger();
	//class destructor
	~Burger();
	//function to display different types of burgers
	void BurgerMenu();
	
	
};
#endif