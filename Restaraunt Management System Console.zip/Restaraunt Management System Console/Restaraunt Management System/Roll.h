#ifndef ROLL_H
#define ROLL_H
#include "Menu.h"
//class Roll is inheriting properties of class Menu by virtual public inheritance due to ambiguity
class Roll : virtual public Menu {
	protected:
	//variable to initialize roll prices
	int MayoRoll;
	int ChatniRoll;
	int CreamyRoll;
	int choiceRoll;
	public:
	//constructor
	Roll();
	//destructor
	~Roll();
	//function to show roll menu
	void RollMenu();
	
	
	
	
};
#endif